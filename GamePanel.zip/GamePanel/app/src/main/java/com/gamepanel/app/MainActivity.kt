package com.gamepanel.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(16)) }
        fun b(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
        root.addView(TextView(this).apply { text = "Game Panel"; textSize = 24f })
        status = TextView(this); root.addView(status)
        val pkg = Uri.parse("package:$packageName")
        b("1. Izin tampil di atas aplikasi lain") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) }
        b("2. Izin ubah setelan sistem (kecerahan)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg)) }
        b("3. Izin Jangan Ganggu") { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        b("4. Aktifkan Aksesibilitas (deteksi game & tombol tap)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        b("Pilih game") { pickGames() }
        b("Bersihkan RAM sekarang") { toast("${Optimizer.boost(this, null)} aplikasi dibersihkan") }
        b("Nyalakan tombol mengambang") {
            if (!Settings.canDrawOverlays(this)) toast("Beri izin langkah 1 dulu")
            else startForegroundService(Intent(this, FloatingService::class.java))
        }
        b("Matikan tombol mengambang") { stopService(Intent(this, FloatingService::class.java)) }
        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        fun m(ok: Boolean) = if (ok) "✓" else "✗"
        status.text = "Overlay ${m(Settings.canDrawOverlays(this))}  Setelan ${m(Settings.System.canWrite(this))}  " +
            "DND ${m(getSystemService(android.app.NotificationManager::class.java).isNotificationPolicyAccessGranted)}  " +
            "Aksesibilitas ${m(GameAccessibility.inst != null)}\nGame terdaftar: ${Store.games(this).size}"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun pickGames() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val sel = Store.games(this)
        val checked = BooleanArray(apps.size) { apps[it].activityInfo.packageName in sel }
        AlertDialog.Builder(this).setTitle("Pilih game")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Simpan") { _, _ ->
                Store.setGames(this, apps.indices.filter { checked[it] }.map { apps[it].activityInfo.packageName }.toSet())
                onResume()
            }.show()
    }
}
