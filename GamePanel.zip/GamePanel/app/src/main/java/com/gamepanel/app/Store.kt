package com.gamepanel.app

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

/** type: TAP, LONG, VOL_UP, VOL_DOWN. (x,y)=posisi tombol, (tx,ty)=target ketukan */
data class Btn(var label: String, var type: String, var x: Int, var y: Int, var tx: Int, var ty: Int)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("gp", 0)
    fun games(c: Context): Set<String> = p(c).getStringSet("games", emptySet())!!.toSet()
    fun setGames(c: Context, s: Set<String>) = p(c).edit().putStringSet("games", s).apply()

    fun buttons(c: Context): MutableList<Btn> {
        val out = mutableListOf<Btn>()
        val a = JSONArray(p(c).getString("btns", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Btn(o.getString("l"), o.getString("t"), o.getInt("x"), o.getInt("y"), o.getInt("tx"), o.getInt("ty")))
        }
        return out
    }

    fun saveButtons(c: Context, l: List<Btn>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("l", it.label).put("t", it.type).put("x", it.x).put("y", it.y).put("tx", it.tx).put("ty", it.ty)) }
        p(c).edit().putString("btns", a.toString()).apply()
    }
}

object Optimizer {
    /** Menutup proses latar aplikasi lain (kecuali game & aplikasi ini). Mengembalikan jumlah aplikasi yang diproses. */
    fun boost(c: Context, keep: String?): Int {
        val am = c.getSystemService(ActivityManager::class.java)
        val games = Store.games(c)
        var n = 0
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        for (ri in c.packageManager.queryIntentActivities(q, 0)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == c.packageName || pkg == keep || pkg in games) continue
            am.killBackgroundProcesses(pkg); n++
        }
        return n
    }

    fun setDnd(c: Context, on: Boolean): Boolean {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return true
    }

    fun isDnd(c: Context) = c.getSystemService(NotificationManager::class.java).currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
}
