package com.gamepanel.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class GameAccessibility : AccessibilityService() {
    companion object { var inst: GameAccessibility? = null }

    private var current: String? = null
    private var dndByUs = false

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        if (pkg in Store.games(this)) {
            if (current != pkg) {
                current = pkg
                Optimizer.boost(this, pkg)
                if (!Optimizer.isDnd(this) && Optimizer.setDnd(this, true)) dndByUs = true
            }
        } else if (current != null) {
            current = null
            if (dndByUs) { Optimizer.setDnd(this, false); dndByUs = false }
        }
    }

    fun tap(x: Float, y: Float, durationMs: Long) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        dispatchGesture(g, null, null)
    }
}
