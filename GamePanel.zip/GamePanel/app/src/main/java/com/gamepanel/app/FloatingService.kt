package com.gamepanel.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.view.WindowManager.LayoutParams.*
import android.widget.*
import kotlin.math.abs

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val extra = mutableListOf<View>()
    private var editMode = false
    private val S get() = dp(48)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gp", "Game Panel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "gp").setContentTitle("Game Panel aktif")
            .setSmallIcon(android.R.drawable.ic_menu_manage).build()
        startForeground(1, n)
        showBubble(); renderButtons()
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }; hidePanel(); clearExtra()
        super.onDestroy()
    }

    private fun lp() = WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, TYPE_APPLICATION_OVERLAY,
        FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        .apply { gravity = Gravity.TOP or Gravity.START }

    private fun circle(text: String, color: Int): TextView = TextView(this).apply {
        this.text = text; setTextColor(Color.WHITE); textSize = 11f; gravity = Gravity.CENTER
        width = S; height = S
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        alpha = 0.85f
    }

    private fun drag(v: View, p: WindowManager.LayoutParams, onClick: () -> Unit, onMoved: () -> Unit = {}) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { p.x = ox + dx; p.y = oy + dy; wm.updateViewLayout(v, p) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (moved) onMoved() else onClick(); true }
                else -> false
            }
        }
    }

    private fun showBubble() {
        val v = circle("⚡", Color.parseColor("#FF6D00"))
        val p = lp().apply { x = 0; y = dp(200) }
        drag(v, p, { if (panel == null) showPanel() else hidePanel() })
        wm.addView(v, p); bubble = v
    }

    // ---------- Panel ----------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) }
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 12f }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply { setColor(Color.parseColor("#E6202124")); cornerRadius = dp(16).toFloat() }
        }
        box.addView(label("Kecerahan"))
        box.addView(SeekBar(this).apply {
            max = 255
            progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    if (!Settings.System.canWrite(this@FloatingService)) { toast("Beri izin 'Ubah setelan sistem' di aplikasi"); return }
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        val am = getSystemService(AudioManager::class.java)
        box.addView(row(
            btn("Volume −") { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) },
            btn("Volume +") { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }))
        box.addView(row(
            btn("Jangan ganggu") {
                if (!Optimizer.setDnd(this, !Optimizer.isDnd(this))) toast("Beri izin Jangan Ganggu di aplikasi")
                else toast(if (Optimizer.isDnd(this)) "Jangan ganggu: ON" else "Jangan ganggu: OFF")
            },
            btn("Bersihkan RAM") { toast("${Optimizer.boost(this, null)} aplikasi dibersihkan") }))
        box.addView(row(
            btn("Wi-Fi") { open(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) },
            btn("Bluetooth") { open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }))
        box.addView(label("Tambah tombol"))
        box.addView(row(btn("Tap") { addBtn("TAP", "Tap") }, btn("Tahan") { addBtn("LONG", "Tahan") }))
        box.addView(row(btn("Vol+") { addBtn("VOL_UP", "Vol+") }, btn("Vol−") { addBtn("VOL_DOWN", "Vol−") }))
        box.addView(row(
            btn(if (editMode) "Selesai edit" else "Edit tombol") { editMode = !editMode; renderButtons(); hidePanel() },
            btn("Tutup") { hidePanel() }))
        if (editMode) box.addView(label("Edit: geser untuk pindah, ketuk tombol untuk hapus. Tanda + = titik target ketukan."))
        val p = lp().apply { width = dp(280); gravity = Gravity.CENTER }
        wm.addView(box, p); panel = box
    }

    private fun hidePanel() { panel?.let { wm.removeView(it) }; panel = null }

    private fun open(i: Intent) { hidePanel(); startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    // ---------- Tombol shortcut ----------
    private fun clearExtra() { extra.forEach { runCatching { wm.removeView(it) } }; extra.clear() }

    private fun addBtn(type: String, label: String) {
        val l = Store.buttons(this); val dm = resources.displayMetrics
        l.add(Btn(label, type, dm.widthPixels / 2 - dp(80), dm.heightPixels / 2, dm.widthPixels / 2 + dp(80), dm.heightPixels / 2))
        Store.saveButtons(this, l); editMode = true; hidePanel(); renderButtons()
        toast("Geser tombol ke posisi yang diinginkan, lalu buka panel > Selesai edit")
    }

    private fun run(b: Btn) {
        when (b.type) {
            "VOL_UP" -> getSystemService(AudioManager::class.java).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "VOL_DOWN" -> getSystemService(AudioManager::class.java).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            else -> {
                val a = GameAccessibility.inst
                if (a == null) toast("Aktifkan Aksesibilitas Game Panel dulu")
                else a.tap((b.tx + S / 2).toFloat(), (b.ty + S / 2).toFloat(), if (b.type == "LONG") 700 else 50)
            }
        }
    }

    private fun renderButtons() {
        clearExtra()
        val list = Store.buttons(this)
        for (b in list) {
            val v = circle(b.label, if (editMode) Color.parseColor("#1565C0") else Color.parseColor("#2E7D32"))
            val p = lp().apply { x = b.x; y = b.y }
            if (editMode) {
                drag(v, p, { list.remove(b); Store.saveButtons(this, list); renderButtons() },
                    { b.x = p.x; b.y = p.y; Store.saveButtons(this, list) })
            } else v.setOnClickListener { run(b) }
            wm.addView(v, p); extra.add(v)
            if (editMode && (b.type == "TAP" || b.type == "LONG")) {
                val t = circle("+", Color.parseColor("#C62828"))
                val tp = lp().apply { x = b.tx; y = b.ty }
                drag(t, tp, {}, { b.tx = tp.x; b.ty = tp.y; Store.saveButtons(this, list) })
                wm.addView(t, tp); extra.add(t)
            }
        }
    }
}
